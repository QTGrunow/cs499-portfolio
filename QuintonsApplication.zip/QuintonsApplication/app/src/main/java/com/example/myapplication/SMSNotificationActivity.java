package com.example.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final String TAG = "SMSNotificationActivity";
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private static final String TEST_PHONE_NUMBER = "5556";

    private TextView permissionStatusTextView;
    private Button requestPermissionButton;
    private EditText messageEditText;
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        initializeViews();
        updatePermissionStatus();
        setupListeners();
    }

    /**
     * Initializes all views from the layout.
     */
    private void initializeViews() {
        permissionStatusTextView = findViewById(R.id.permissionStatusTextView);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
    }

    /**
     * Sets click listeners for buttons.
     */
    private void setupListeners() {
        requestPermissionButton.setOnClickListener(v -> requestSMSPermission());
        sendButton.setOnClickListener(v -> sendMessage());
    }

    /**
     * Requests SMS permission if it has not already been granted.
     */
    private void requestSMSPermission() {
        if (hasSMSPermission()) {
            permissionStatusTextView.setText("SMS permission is already granted");
            showMessagingControls(true);
            Toast.makeText(this, "SMS permission already granted.", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    /**
     * Handles the permission request result.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatusTextView.setText("SMS permission granted");
                showMessagingControls(true);
                Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                permissionStatusTextView.setText("SMS permission denied");
                showMessagingControls(false);
                Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Sends an SMS message if permission is granted and the message is valid.
     */
    private void sendMessage() {
        if (!hasSMSPermission()) {
            Toast.makeText(this, "SMS permission is required to send messages.", Toast.LENGTH_SHORT).show();
            return;
        }

        String message = getTrimmedMessage();

        if (TextUtils.isEmpty(message)) {
            messageEditText.setError("Please enter a message");
            Toast.makeText(this, "Please enter a message.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(TEST_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(this, "Message sent successfully.", Toast.LENGTH_LONG).show();
            messageEditText.setText("");
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS message", e);
            Toast.makeText(this, "Message sending failed.", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Updates the permission status text and shows or hides messaging controls.
     */
    private void updatePermissionStatus() {
        if (hasSMSPermission()) {
            permissionStatusTextView.setText("SMS permission is granted");
            showMessagingControls(true);
        } else {
            permissionStatusTextView.setText("SMS permission is not granted");
            showMessagingControls(false);
        }
    }

    /**
     * Returns true if SMS permission is granted.
     */
    private boolean hasSMSPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Shows or hides the message input and send button.
     */
    private void showMessagingControls(boolean isVisible) {
        int visibility = isVisible ? View.VISIBLE : View.GONE;
        messageEditText.setVisibility(visibility);
        sendButton.setVisibility(visibility);
    }

    /**
     * Returns the trimmed message text from the input field.
     */
    private String getTrimmedMessage() {
        return messageEditText.getText() == null
                ? ""
                : messageEditText.getText().toString().trim();
    }
}