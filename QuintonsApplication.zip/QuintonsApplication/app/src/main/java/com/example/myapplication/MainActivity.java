package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private Button viewDataButton;
    private Button smsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setButtonListeners();
    }

    private void initializeViews() {
        viewDataButton = findViewById(R.id.viewDataButton);
        smsButton = findViewById(R.id.smsButton);
    }

    private void setButtonListeners() {
        viewDataButton.setOnClickListener(v -> navigateToDataDisplay());
        smsButton.setOnClickListener(v -> navigateToSMSNotification());
    }

    private void navigateToDataDisplay() {
        try {
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening DataDisplayActivity", e);
            Toast.makeText(this, "Unable to open data display screen.", Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToSMSNotification() {
        try {
            Intent intent = new Intent(MainActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error opening SMSNotificationActivity", e);
            Toast.makeText(this, "Unable to open SMS notification screen.", Toast.LENGTH_SHORT).show();
        }
    }
}