package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.Collections;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView dataRecyclerView;
    private FloatingActionButton addDataButton;
    private DataAdapter dataAdapter;
    private DataEntryDatabase dataEntryDatabase;
    private TextInputLayout inputLayoutData1;
    private TextInputLayout inputLayoutData2;
    private TextInputEditText editTextData1;
    private TextInputEditText editTextData2;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addDataButton = findViewById(R.id.addDataButton);
        inputLayoutData1 = findViewById(R.id.inputLayoutData1);
        inputLayoutData2 = findViewById(R.id.inputLayoutData2);
        editTextData1 = findViewById(R.id.editTextData1);
        editTextData2 = findViewById(R.id.editTextData2);
        submitButton = findViewById(R.id.submitButton);

        dataEntryDatabase = new DataEntryDatabase(this);

        ArrayList<DataModel> dataList = dataEntryDatabase.getAllData();
        Collections.sort(dataList, (a, b) -> a.getData1().compareToIgnoreCase(b.getData1()));

        dataAdapter = new DataAdapter(dataList, dataEntryDatabase);

        dataRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataRecyclerView.setAdapter(dataAdapter);

        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddDataFields();
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitData();
            }
        });
    }

    private void showAddDataFields() {
        inputLayoutData1.setVisibility(View.VISIBLE);
        inputLayoutData2.setVisibility(View.VISIBLE);
        submitButton.setVisibility(View.VISIBLE);
        addDataButton.setVisibility(View.GONE);
    }

    private void submitData() {
        String data1 = editTextData1.getText().toString().trim();
        String data2 = editTextData2.getText().toString().trim();

        if (data1.isEmpty() || data2.isEmpty()) {
            Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        dataEntryDatabase.addData(data1, data2);
        editTextData1.getText().clear();
        editTextData2.getText().clear();

        inputLayoutData1.setVisibility(View.GONE);
        inputLayoutData2.setVisibility(View.GONE);
        submitButton.setVisibility(View.GONE);
        addDataButton.setVisibility(View.VISIBLE);

        refreshData();
    }

    private void refreshData() {
        ArrayList<DataModel> dataList = dataEntryDatabase.getAllData();
        Collections.sort(dataList, (a, b) -> a.getData1().compareToIgnoreCase(b.getData1()));
        dataAdapter.updateData(dataList);
    }
}