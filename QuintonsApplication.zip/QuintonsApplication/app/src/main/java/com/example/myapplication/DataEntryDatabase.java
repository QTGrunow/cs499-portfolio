package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DataEntryDatabase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "DataEntryDatabase.db";
    private static final String TABLE_DATA = "data";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATA1 = "data1";
    private static final String COLUMN_DATA2 = "data2";

    public DataEntryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_DATA + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATA1 + " TEXT, " +
                COLUMN_DATA2 + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DATA);
        onCreate(db);
    }

    public long addData(String data1, String data2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATA1, data1);
        values.put(COLUMN_DATA2, data2);
        long result = db.insert(TABLE_DATA, null, values);
        db.close();
        return result;
    }

    public ArrayList<DataEntry> getAllData() {
        ArrayList<DataEntry> dataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_DATA;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String data1 = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATA1));
                String data2 = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATA2));
                DataEntry dataEntry = new DataEntry(id, data1, data2);
                dataList.add(dataEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return dataList;
    }

    public boolean deleteData(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        boolean result = db.delete(TABLE_DATA, "id=?", new String[]{String.valueOf(id)}) > 0;
        db.close();
        return result;
    }
}