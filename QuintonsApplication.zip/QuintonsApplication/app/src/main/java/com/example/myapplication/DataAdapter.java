package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    private ArrayList<DataEntry> dataList;
    private DataEntryDatabase dataEntryDatabase;

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        public TextView data1TextView;
        public TextView data2TextView;
        public Button deleteButton;

        public DataViewHolder(View itemView) {
            super(itemView);
            data1TextView = itemView.findViewById(R.id.data1TextView);
            data2TextView = itemView.findViewById(R.id.data2TextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public DataAdapter(ArrayList<DataEntry> dataList, DataEntryDatabase dataEntryDatabase) {
        this.dataList = dataList;
        this.dataEntryDatabase = dataEntryDatabase;
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_item, parent, false);
        return new DataViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        DataEntry currentItem = dataList.get(position);
        holder.data1TextView.setText(currentItem.getData1());
        holder.data2TextView.setText(currentItem.getData2());
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataEntryDatabase.deleteData(currentItem.getId());
                updateData(dataEntryDatabase.getAllData());
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void updateData(ArrayList<DataEntry> newData) {
        dataList = newData;
        notifyDataSetChanged();
    }
}